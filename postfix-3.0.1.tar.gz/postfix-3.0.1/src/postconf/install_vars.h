char   *var_config_dir;
char   *var_debug_command;
